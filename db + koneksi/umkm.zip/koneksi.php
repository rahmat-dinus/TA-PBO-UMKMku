<?php

 define('HOST','localhost');
 define('USER','u5785535_umkmku'); 
 define('PASS','umkmku'); 
 define('DB','u5785535_umkmku');
 
 //membuat koneksi dengan database
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 ?>