<?php

	include_once "../koneksi.php";

	class usr{}

	$nama = $_POST["nama"];
	$email = $_POST["email"];
	$hp = $_POST["hp"];
	$password = $_POST["password"];
    $uid = random_word(20);

	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM user WHERE email='".$email."' AND hp='".$hp."'"));

	if ($num_rows == 0){
		$query = mysqli_query($con, "INSERT INTO user (uid, nama, email, hp, password) VALUES('".$uid."','".$nama."','".$email."', '".$hp."','".md5($password)."')");
        mkdir("foto/".$uid."");
		if ($query){
			$response = new usr();
			$response->success = 1;

		} else {
			$response = new usr();
			$response->success = 0;
		}
	} else {
		$response = new usr();
		$response->success = 2;
	}
	
	header('Content-Type: application/json');
	echo json_encode($response);
	
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
    		for ($i = 0; $i < $id; $i++){
    			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
    		}
		return $word; 
	}

	mysqli_close($con);

?>	