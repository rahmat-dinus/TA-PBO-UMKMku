<?php

	include_once "../koneksi.php";

	class usr{}
	
	$email = $_POST["email"];
	$password = $_POST["password"];
	
	$query = mysqli_query($con, "SELECT * FROM user WHERE email='$email' AND password=md5('$password')");
	
	$row = mysqli_fetch_array($query);

	
	if (!empty($row)){
		$response = new usr();
		$response->success = 1;
		$response->uid = $row['uid'];
		$response->nama=$row['nama'];
		$response->email=$row['email'];
		$response->hp=$row['hp'];
		$response->foto=$row['foto'];
	} else { 
		$response = new usr();
		$response->success = 0;
	}
	
	header('Content-Type: application/json');
	echo json_encode($response);
	
	mysqli_close($con);

?>