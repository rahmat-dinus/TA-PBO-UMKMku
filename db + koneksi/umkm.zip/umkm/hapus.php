<?php 
	require_once('../koneksi.php');

	class usr{}
	
	$uid = $_GET['uid'];
	
	$query = mysqli_query($con, "DELETE FROM `umkm` WHERE `uid` = '$uid'");

	
	if ($query){
		$response = new usr();
		$response->success = 1;
	} else { 
		$response = new usr();
		$response->success = 0;
	}
	
	header('Content-Type: application/json');
	echo json_encode($response);
	
	mysqli_close($con);
?>