<?php 
	require_once('../koneksi.php');
	
	$sql = "SELECT * FROM `umkm` ORDER BY 'uid'";
	$r = mysqli_query($con,$sql);
	$result = array();
	
	while($row = mysqli_fetch_array($r)){
		
		array_push($result,array(
			"uid"=>$row['uid'],
			"nama_umkm"=>$row['nama_umkm'],
			"hp_umkm"=>$row['hp_umkm'],
			"email_umkm"=>$row['email_umkm'],
			"longitude"=>$row['longitude'],
			"latitude"=>$row['latitude'],
			"count_populer"=>$row['count_populer'],
			"foto"=>"http://nardoogroup.com/umkmku/umkm/".$row['foto'],
			"created_at"=>$row['created_at']
		));
	}
	
	header('Content-Type: application/json');
	echo json_encode($result);
	
	mysqli_close($con);
?>