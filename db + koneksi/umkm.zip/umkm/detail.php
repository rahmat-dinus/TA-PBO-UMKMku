<?php 
	require_once('../koneksi.php');

	class usr{}
	
	$uid = $_GET['uid'];
	
	$query = mysqli_query($con, "SELECT * FROM `umkm` WHERE `uid` = '$uid'");
	
	$row = mysqli_fetch_array($query);
	
	if (!empty($row)){
	    $jml = $row['count_populer'] + 1;
        $update = mysqli_query($con, "UPDATE umkm SET count_populer='".$jml."' WHERE uid ='".$uid."'");
        if($update){
            
            $new_query = mysqli_query($con, "SELECT * FROM `umkm` WHERE `uid` = '$uid'");
        	$new_row = mysqli_fetch_array($new_query);  
	
            if($new_query){
                $response = new usr();
        		$response->success = 1;
        		$response->count_populer = $new_row['count_populer'];
        		$response->uid = $new_row['uid'];
        		$response->nama_umkm=$new_row['nama_umkm'];
        		$response->hp_umkm=$new_row['hp_umkm'];
        		$response->email_umkm=$new_row['email_umkm'];
        		$response->nama_pemilik=$new_row['nama_pemilik'];
        		$response->hp_pemilik=$new_row['hp_pemilik'];
        		$response->email_pemilik=$new_row['email_pemilik'];
        		$response->longitude=$new_row['longitude'];
        		$response->latitude=$new_row['latitude'];
        		$response->foto="http://nardoogroup.com/umkmku/umkm/".$new_row['foto'];
        		$response->created_at=$new_row['created_at'];
        		$response->updated_at=$new_row['updated_at'];
            }
        }
	} else { 
		$response = new usr();
		$response->success = 0;
	}
	
	header('Content-Type: application/json');
	echo json_encode($response);
	
	mysqli_close($con);
?>