<?php
	include_once "../koneksi.php";

	class umkm{}

	$uid = $_GET["uid"];

	$nama_umkm = $_POST["nama_umkm"];
	$hp_umkm = $_POST["hp_umkm"];
	$email_umkm = $_POST["email_umkm"];
	$nama_pemilik = $_POST["nama_pemilik"];
	$hp_pemilik = $_POST["hp_pemilik"];
	$email_pemilik = $_POST["email_pemilik"];
	$longitude = $_POST["longitude"];
	$latitude = $_POST["latitude"];

	$lokasi_file = $_FILES['foto']['tmp_name'];
    $nama_file = $_FILES['foto']['name'];


	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM umkm WHERE uid='".$uid."'"));

	if ($num_rows == 1){
		if(!empty($lokasi_file)){
	        $foto="foto/".$uid."/".date("y-m-d_h-i-sa").".".pathinfo($nama_file, PATHINFO_EXTENSION);
	        move_uploaded_file($lokasi_file,$foto);

	        $query = mysqli_query($con, "UPDATE umkm SET nama_umkm='".$nama_umkm."', hp_umkm='".$hp_umkm."' , email_umkm = '".$email_umkm."', nama_pemilik = '".$nama_pemilik."', hp_pemilik = '".$hp_pemilik."', email_pemilik ='".$email_pemilik."', longitude = '".$longitude."', latitude = '".$latitude."', foto= '".$foto."' WHERE uid ='".$uid."' ");
		}else{
			$query = mysqli_query($con, "UPDATE umkm SET nama_umkm='".$nama_umkm."', hp_umkm='".$hp_umkm."' , email_umkm = '".$email_umkm."', nama_pemilik = '".$nama_pemilik."', hp_pemilik = '".$hp_pemilik."', email_pemilik ='".$email_pemilik."', longitude = '".$longitude."', latitude = '".$latitude."' WHERE uid ='".$uid."' ");
		}

		if ($query){
			$response = new umkm();
			$response->success = 1;

		} else {
			$response = new umkm();
			$response->success = 0;
		}
	} else {
		$response = new umkm();
		$response->success = 2;
	}
	
	header('Content-Type: application/json');
	echo json_encode($response);
	
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
    		for ($i = 0; $i < $id; $i++){
    			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
    		}
		return $word; 
	}

	mysqli_close($con);

?>	